## Advanced MAME Launcher

Advanced MAME Launcher was coded from scratch by Wintermute0110 <wintermute0110@gmail.com>.
The first public released version of Advanced MAME Launcher was 0.9.0 on Jan 2017.

[Kodi forum thread](http://forum.kodi.tv/showthread.php?tid=304186)

### AML contributors

 * PDF rendering code taken from **PDF Reader** addon by i96751414.
   [PDF Reader source code](https://github.com/i96751414/plugin.image.pdfreader)
