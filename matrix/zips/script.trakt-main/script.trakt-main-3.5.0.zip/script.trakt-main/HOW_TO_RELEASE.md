1. Write changelog in changelog.txt
2. Update addon.xml - the version and the news tag
3. Push to github wait for CI
4. Create a new git tag and push it `git tag vX.X.X && git push --tags`
