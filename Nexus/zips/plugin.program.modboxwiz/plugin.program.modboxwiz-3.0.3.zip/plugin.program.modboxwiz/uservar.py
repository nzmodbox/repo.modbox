import xbmcaddon

'''#####-----Build File-----#####'''
buildfile = 'http://CHANGEME'

'''#####-----Notifications File-----#####'''
notify_url  = 'http://slamiousproject.com/wzrd/notify19.txt'

'''#####-----Excludes-----#####'''
excludes  = ['plugin.video.whatever']
